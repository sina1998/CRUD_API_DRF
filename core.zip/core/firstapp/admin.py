from django.contrib import admin
from firstapp.models import userModel

admin.site.register(userModel)

